function setup() {
  createCanvas(400, 400);
}

let img;

// Load the image.
function preload() {
  img = loadImage('map.jpg');
}

function setup() {
  createCanvas(600, 600);

  background(600);

  // Draw the image and scale it to fit within the canvas.
  image(img, 0, 0, width, height, 0, 0, img.width, img.height, CONTAIN);
}